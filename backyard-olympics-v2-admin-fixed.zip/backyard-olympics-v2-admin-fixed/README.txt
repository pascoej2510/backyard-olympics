Backyard Olympics V2 - Admin Fixed

Upload/replace these files in your GitHub Pages repository:
- index.html
- styles.css
- app.js
- config.js

Admin page:
?view=admin

TV page:
?view=tv

Captain links are shown inside Admin.

Fixes in this version:
- Admin fields are editable immediately.
- Use Save Admin Changes button instead of onchange fields.
- Admin screen does not auto-refresh while typing.
- Button handlers are available before the first render.

Note: Until Firebase is connected, different phones will not share live scores. The app will still work on one device for testing.
